from concurrent.futures import ThreadPoolExecutor
from genai_app.config import CONFIG, SCENARIOS, CHOICES_URL
from genai_app.genai_output import get_genai_output
from genai_app.choices import get_choice_data, preprocess_choices
from genai_app.utils.matcher import infer_key
from genai_app.utils.logger import logger


def process_scenario(scenario, choices, config):
    """
    Process a single GenAI scenario.

    Args:
        scenario (int): Scenario ID.
        choices (dict): Valid key-value options.
        config (dict): Configuration settings.
    """
    logger.info(f"Processing scenario {scenario}...")
    try:
        genai_output = get_genai_output(scenario)
        logger.debug(f"GenAI output for scenario {scenario}: {genai_output}")
        fixed_output = {}
        output_message = ""

        for k, v in genai_output.items():
            logger.debug(f"Processing key-value pair: {k} -> {v}")
            inferred_key, inferred_value, score, original_key = infer_key(
                k, v, choices, config["matching_method"], config["threshold"]
            )
            fixed_output[inferred_key] = inferred_value
            if original_key:
                output_message += f"Inferred key '{original_key}' as '{inferred_key}'.\n"
            if score < config["threshold"]:
                output_message += f"Inferred value '{v}' as '{inferred_value}'.\n"

        logger.info(f"Scenario {scenario} processed: {fixed_output}")
        logger.debug(output_message)

    except Exception as e:
        logger.error(f"Error processing scenario {scenario}: {e}")


def process_all_scenarios():
    """Process all GenAI scenarios."""
    logger.info("Starting to process all scenarios...")
    try:
        # Fetch and preprocess choices with caching
        choices = get_choice_data(CHOICES_URL)
        logger.debug(f"Choices data: {choices}")

        preprocessed_choices = preprocess_choices(
            choices,
            lambda key, value_list: [
                infer_key(value, key, choices, CONFIG["matching_method"], CONFIG["threshold"])
                for value in value_list
            ],
        )
        logger.info("Preprocessed choices successfully.")

        # Process scenarios in parallel
        with ThreadPoolExecutor() as executor:
            logger.info("Submitting scenarios to ThreadPoolExecutor...")
            executor.map(
                lambda scenario: process_scenario(scenario, preprocessed_choices, CONFIG),
                range(len(SCENARIOS)),
            )

        logger.info("All scenarios processed successfully.")
    except Exception as e:
        logger.error(f"Error processing all scenarios: {e}")


if __name__ == "__main__":
    process_all_scenarios()
